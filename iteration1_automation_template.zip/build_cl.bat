@echo off
setlocal

cd /d "%~dp0"

rem Use the MSVC compiler bundled with Visual Studio 2022.
rem If your Visual Studio is installed elsewhere, edit the path below.
call "D:\Visual Studio\Vs 2022\VC\Auxiliary\Build\vcvars64.bat"

cl /nologo /W4 /std:c11 /utf-8 ^
  /I third_party\cjson ^
  /I src ^
  src\test_runner.c ^
  src\game_engine_stub.c ^
  third_party\cjson\cJSON.c ^
  /Fe:rich_test.exe

if %ERRORLEVEL% NEQ 0 (
    echo Build failed. See the error messages above.
    exit /b %ERRORLEVEL%
)

echo Build succeeded: rich_test.exe
endlocal
